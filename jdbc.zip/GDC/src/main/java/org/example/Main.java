package org.example;

import org.postgresql.jdbc.PgConnection;
import org.postgresql.jdbc.PgDatabaseMetaData;

public class Main {
    public static void main(String[] args) {

    }
}