package org.example.utils;

import lombok.Data;


public class Context {
    private static String user;
    public static String getUser(){
        return user;
    }
    public static void setUser(String username){
        user=username;
    }
}
