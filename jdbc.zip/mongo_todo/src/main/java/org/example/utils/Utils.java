package org.example.utils;

import java.util.Scanner;

public interface Utils {
    Scanner scanner = new Scanner(System.in);
    Scanner strScanner = new Scanner(System.in);
    static String enterStr(String hint){
        System.out.print(hint);
        return strScanner.nextLine();
    }
    static Integer enterInt(String hint, AccepterType type) {
        try{
            System.out.print(hint);
            if(type.equals(AccepterType.CHOICE)){
                System.out.print("Enter your choice --> ");
            }
            return scanner.nextInt();

        }catch (Exception e){
            System.out.println("Something went wrong try again!");
            scanner.nextLine();
            return enterInt(hint, type);
        }
    }
    static Integer enterDouble(String hint) {
        try{
            System.out.print(hint);
            return scanner.nextInt();

        }catch (Exception e){
            System.out.println("Something went wrong try again!");
            scanner.nextLine();
            return enterDouble(hint);
        }
    }

    enum AccepterType {
        DEFAULT,
        CHOICE
    }
}
