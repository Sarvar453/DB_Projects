package org.example;
import org.example.Services.ToDoService;
import org.example.Services.UserService;
import org.example.utils.Utils;

import java.util.logging.Level;
import java.util.logging.Logger;

public class Main {
    public static void main(String[] args) {
        Logger.getLogger("org.mongodb.driver").setLevel(Level.SEVERE);
        reg_menu();
    }
    private static void reg_menu(){
        while (true){
            switch (Utils.enterInt("""
                    0. Exit
                    1. Sign in
                    2. Sign up
                    """,Utils.AccepterType.CHOICE)){
                case 0 -> System.out.println("See you soon!");
                case 1 -> {
                    if (UserService.signIn()) {
                        main_menu();
                    }
                }
                case 2 -> UserService.signUp();
            }
        }
    }
    private static void main_menu(){
        while (true){
            switch (Utils.enterInt("""
                    0. Back
                    1. Show todos
                    2. Add todo
                    3. Complete todo
                    """,Utils.AccepterType.CHOICE)){
                case 0 -> reg_menu();
                case 1 -> ToDoService.show_todos();
                case 2 -> ToDoService.add_todo();
                case 3 -> ToDoService.complete_todo();
            }
        }
    }
}