package org.example.config;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoDatabase;

public class MongoDbConfig {
    public static final MongoClient client = new MongoClient( "localhost" , 27017 );
    public static final MongoDatabase database = client.getDatabase("todo_app");
}
