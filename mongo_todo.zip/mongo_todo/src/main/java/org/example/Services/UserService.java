package org.example.Services;

import com.mongodb.client.MongoCollection;
import org.bson.Document;
import org.example.config.MongoDbConfig;
import org.example.utils.Context;
import org.example.utils.Utils;
import java.util.regex.Pattern;

public class UserService {
    public static final MongoCollection<Document> users = MongoDbConfig.database.getCollection("users");
    public static boolean signIn() {
        String userName = Utils.enterStr("Enter your username --> ");
        String password = Utils.enterStr("Enter your password --> ");
        Document query = new Document("username", userName);
        Document userDoc = users.find(query).first();
        if(userDoc!=null){
            String userPassword = userDoc.getString("password");
            if(userPassword.equals(password)){
                Context.setUser(userName);
                System.out.println("Welcome "+userDoc.getString("username")+"!");
                return true;
            }
        }
        System.out.println("You entered wrong username or password!");
        return false;
    }

    public static boolean signUp() {
        String userName = Utils.enterStr("Enter your username --> ");
        String email = Utils.enterStr("Enter your email --> ");
        String phoneNumber = Utils.enterStr("Enter your phone number --> ");
        String password = Utils.enterStr("Enter your password --> ");

        Document query = new Document("username", userName);
        Document userDoc = users.find(query).first();
        if(userDoc==null){
            if (!emailValidation(email)){
                System.out.println("Invalid email format. Must end with @gmail.com or @mail.ru");
                return false;
            }
            if(!passwordValidation(password)){
                System.out.println("Password must be at least 8 characters, with at least 1 uppercase letter and 1 special symbol.");
                return false;
            }
            Document newUser = Document.parse("""
                    {
                      "username":"%s",
                      "email":"%s",
                      "phone_number":"%s",
                      "password":"%s",
                      "active":true
                    }
                    """.formatted(userName,email,phoneNumber,password));
            users.insertOne(newUser);
            System.out.println("Successfully registered!");

            return true;
        }
        System.out.println("user with the same name already exists!");
        return false;
    }
    private static boolean emailValidation(String email) {
        String regex = "^[a-zA-Z0-9._%+-]+@(gmail\\.com|mail\\.ru)$";
        return Pattern.matches(regex, email);
    }

    private static boolean passwordValidation(String password) {
        String regex = "^(?=.*[A-Z])(?=.*[!@#$%^&*()_+=\\[\\]{};':\"|,.<>/?-])[A-Za-z\\d!@#$%^&*()_+=\\[\\]{};':\"|,.<>/?-]{8,}$";
        return Pattern.matches(regex, password);
    }
}
