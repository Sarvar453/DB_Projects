package org.example.Services;

import com.mongodb.BasicDBObject;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Updates;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.example.config.MongoDbConfig;
import org.example.utils.Context;
import org.example.utils.Utils;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ToDoService {
    private static final MongoCollection<Document> users = MongoDbConfig.database.getCollection("users");
    public static void show_todos(){
        BasicDBObject filter = new BasicDBObject("username", Context.getUser());
        BasicDBObject projection = new BasicDBObject("todos", 1).append("_id", 0);
        FindIterable<Document> iterable = users.find(filter).projection(projection);
        for (Document document : iterable){
            System.out.println(document.toJson());
        }
    }
    public static void add_todo(){
        String title = Utils.enterStr("Enter todo title --> ");
        String description = Utils.enterStr("Enter todo description --> ");
        String date = Utils.enterStr("Enter date of todo --> ");
        Integer priority = Utils.enterInt("Enter priority (1-3) --> ", Utils.AccepterType.DEFAULT);
        Date dueDate = null;
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            dueDate = dateFormat.parse(date);
        } catch (Exception e) {
            System.out.println("Invalid date format. Please use yyyy-MM-dd");
            return;
        }
        Document newTodo = new Document("_id", new ObjectId())
                .append("title",title)
                .append("description", description)
                .append("completed", false)
                .append("dueDate", dueDate)
                .append("priority", priority);
        BasicDBObject filter = new BasicDBObject("username", Context.getUser());
        users.updateOne(filter, Updates.push("todos",newTodo));
    }
    public static void complete_todo(){
        String todo_id = Utils.enterStr("Enter the id of todo --> ");
        BasicDBObject filter = new BasicDBObject("username", Context.getUser()).append("todos._id", new ObjectId(todo_id));
        users.updateOne(filter, Updates.set("todos.$.completed", true));
    }
}
